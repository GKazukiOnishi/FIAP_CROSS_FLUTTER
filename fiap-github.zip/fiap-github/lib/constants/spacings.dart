class Spacings {
  static const double zero = 0;
  static const double XS = 4;
  static const double S = 8;
  static const double M = 16;
  static const double L = 24;
  static const double XL = 32;
  static const double XXL = 48;
}
