package com.fiap.github

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
